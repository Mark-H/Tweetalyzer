<?php

$_lang['tweetalyzer.neg'] = 'Negative';
$_lang['tweetalyzer.neu'] = 'Neutral';
$_lang['tweetalyzer.pos'] = 'Positive';

$_lang['tweetalyzer.summary'] = 'Out of [[+total]] collected tweets, [[+pos]] were Positive, [[+neu]] were Neutral and [[+neg]] were Negative.';


?>
