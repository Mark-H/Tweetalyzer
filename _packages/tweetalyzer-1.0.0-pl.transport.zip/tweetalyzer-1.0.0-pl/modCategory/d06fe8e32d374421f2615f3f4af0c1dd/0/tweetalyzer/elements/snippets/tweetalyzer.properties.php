<?php
return array(
    'search' => '#modx',
    'amount' => 10,
    'registerCss' => true,
    'tweetTpl' => 'tweetalyzerTweet',
    'outerTpl' => 'tweetalyzerOuter',
    'tweetSeparator' => '',
);
